import sys
import glob
import os
import select
import time
import csv
import importlib
from qiskit import QuantumCircuit, transpile
from qiskit_aer import Aer
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2 as Sampler
from concurrent.futures import ProcessPoolExecutor
from _fake_backends import backends as fake_backends
from get_remote_results import get_remote_results

#macario.polo@uclm.es
IBM_INSTANCE = "crn:v1:bluemix:public:quantum-computing:us-east:a/f36be7dffb684988a853d020195b1761:3896a033-cd37-497c-ad48-c53c7dd17f22::"
#CLAVE_DE_API = "3TnMdfAfSaJ7k0vzmB48oBqYX1f6D-XrugCF86BlLWtK"
#macario.polo@uclm.es
IBM_TOKEN = "w5nqrDyPN_89VDZMKT-8NuhoqxAHdsA7SwCmT-tFgYYs"

#macario.polo.pruebas@gmail.com
#API_KEY = "TB3AbU7rojDclYNCpmcy9gzrpwqXYw0zJzaOd1ERn-YL"


# --------------------------------------------------------------------
# MENÚ DE OPCIONES
# --------------------------------------------------------------------
def menu(timeout=2, default="1") -> str:
    opciones = {
        "1": "Solo simulador",
        "2": "Solo fake_backends",
        "3": "Simulator + fake_backends",
        "4": "Solo actual_backends",
        "5": "Todos"
    }
    print("\n¿Qué deseas ejecutar?")
    for k, v in opciones.items():
        print(f"{k}) {v}")
    print(f"⏳ Tienes {timeout} segundos [{default}]: ", end="", flush=True)

    ready, _, _ = select.select([sys.stdin], [], [], timeout)
    if ready:
        sel = sys.stdin.readline().strip()
        print(f"Opción elegida: {sel}")
        return sel
    else:
        print(f"\n⌛ Tiempo superado. Por defecto: {default}")
        return default

# --------------------------------------------------------------------
# IMPORTAR DINÁMICAMENTE MÓDULOS POR RUTA
# --------------------------------------------------------------------
def load_module_from_path(path: str):
    """Carga un módulo Python dado su filepath sin necesidad de instalarlo."""
    module_name = os.path.splitext(os.path.basename(path))[0]
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"No se pudo cargar el módulo desde {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

# ALMACENAMIENTO DEL CIRCUITO TRANSPILADO
def save_transpiled_circuit(circuit: QuantumCircuit, backend, path : str, transpilation_time) :
    backend_name = backend.name if hasattr(backend, "name") else backend.backend_name
    lines = [
        "# Circuito transpilado automáticamente",
        "# ßackend : " + backend_name,
        "# Time: " + str(transpilation_time),
        "from qiskit import QuantumCircuit",
        "",
        "class TranspiledCircuit:",
        "\tdef __init__(self, qubits=None):"
    ]

    # Crear el mapa de cúbits usados
    qubit_map = {}
    physical_qubits = []
    index = 0
    for instr in circuit.data:
        for qubit in instr.qubits:
            if qubit not in qubit_map:
                qubit_index = circuit.qubits.index(qubit)
                qubit_map[qubit] = index
                physical_qubits.append(qubit_index)
                index += 1

    # Inicialización de self.qubits con los índices físicos usados
    lines.append(f"\t\toriginal_qubits = {physical_qubits}")
    lines.append(f"\t\tself.qubits = range(0, {len(physical_qubits)})  if qubits is None else original_qubits")
    lines.append("")

    # get_circuit()
    lines.append("\tdef get_circuit(self, targetQubits=None):")
    lines.append(f"\t\tcircuit = QuantumCircuit({circuit.num_qubits}, {circuit.num_clbits})")
    lines.append("\t\tif targetQubits is None:")
    lines.append("\t\t\ttargetQubits = self.qubits")

    for instr in circuit.data:
        operation = instr.operation
        params = operation.params
        qargs = [f"targetQubits[{qubit_map[q]}]" for q in instr.qubits]
        cargs = [str(circuit.clbits.index(c)) for c in instr.clbits]
        params_str = ", ".join(map(str, params))
        all_args = qargs + cargs
        args_str = ", ".join(all_args)
        if len(params_str)>0 :
            lines.append(f"\t\tcircuit.{operation.name}({params_str}, {args_str})")
        else :
            if operation.name == "measure":
                lines.append(f"\t\t#circuit.{operation.name}({args_str})")
            else :
                lines.append(f"\t\tcircuit.{operation.name}({args_str})")

    lines.append("\t\t#print(circuit)")
    lines.append("\t\treturn circuit")
    lines.append("\n")
    lines.append("if __name__ == \"__main__\":")
    lines.append("\ttc = TranspiledCircuit()")
    lines.append("\ttc.get_circuit()")

    base, _ = os.path.splitext(path)
    transpiled_path = base + "." + backend_name + ".py"
    with open(transpiled_path, 'w', encoding='utf-8') as f:
        f.write("\n".join(lines))
    return True

# --------------------------------------------------------------------
# EJECUCIÓN GENÉRICA DE UN CIRCUITO SOBRE UN BACKEND
# --------------------------------------------------------------------
def execute_on_backend(circuit: QuantumCircuit, backend, path = None):
    t0 = time.time()
    #circuit.draw(output="mpl", scale=0.4, plot_barriers=False, filename='/Users/macariopolousaola/Desktop/original.png')
    transpiled = transpile(circuit, backend)
    t_transpile = time.time() - t0
    if path is not None:
        save_transpiled_circuit(transpiled, backend, path, t_transpile)
    #transpiled.draw(output="mpl", scale=0.4, plot_barriers=False, filename='/Users/macariopolousaola/Desktop/transpiled.png')

    t0 = time.time()
    job_id = None
    if not hasattr(backend, "backend_name") :
        sampler = Sampler(backend)
        job = sampler.run([transpiled], shots=shots)
        t_execute = time.time() - t0
        t0 = time.time()
        result = job.result()[0]
        t_result = time.time() - t0
        counts = result.data.c.get_counts()
    elif backend.backend_name.startswith("fake") :
        job = backend.run(transpiled, shots=shots)
        t_execute = time.time() - t0
        t0 = time.time()
        result = job.result()
        t_result = time.time() - t0
        counts = result.get_counts()
    else :
        sampler = Sampler(mode = backend)
        job = sampler.run([transpiled], shots=shots)
        job_id = job.job_id()
        t_execute = time.time() - t0

        with ProcessPoolExecutor(max_workers=1) as exe :
            t0 = time.time()
            future = exe.submit(get_remote_results, job_id, IBM_TOKEN, IBM_INSTANCE)
            counts = future.result()
            t_result = time.time() - t0
        #counts = get_remote_results(job_id, IBM_TOKEN)

    #from qiskit.visualization import plot_histogram
    #import matplotlib.pyplot as plt
    #plot_histogram(counts)
    #plt.show()
    return transpiled, counts, (t_transpile, t_execute, t_result), job_id

# --------------------------------------------------------------------
# FUNCIONES DE DETALLE E INFORME (idénticas a las originales)
# --------------------------------------------------------------------
def find(decimal_key) :
    for i in range(0, len(expected)) :
        if expected[i][0] == decimal_key :
            return expected[i][1] # * len(expected)
    return 0

def print_parallel_details(iteration, problem, counts, backend_name, details_writer):
    blocks = round(qubits // ORIGINAL_QUBITS)
    block_len = int(ORIGINAL_QUBITS)

    '''
    counts = {
        '00000000': 2, '00000001': 6, '00000010': 3, '00000011': 2, '00000100': 3, '00000101': 2, '00000110': 4,
        '00001000': 3, '00001001': 6, '00001010': 1, '00001011': 2, '00001100': 1, '00001101': 1, '00001110': 3,
        '00001111': 946, '00011111': 2, '00101111': 6, '00111111': 4, '01001111': 3, '01011111': 2, '01101111': 1,
        '01111111': 4, '10001111': 1, '10011111': 2, '10101111': 2, '10111111': 2, '11001111': 2, '11011111': 3,
        '11101111': 1, '11111111': 4}

    counts = {
        '00000': 510, '00011': 2, '00100': 2, '00101': 1, '00110': 1, '00111': 1, '01000': 2, '01001': 1, '01100': 1,
        '01110': 2, '10000': 2, '10001': 3, '10010': 3, '10011': 2, '10100': 2, '10101': 2, '10110': 1, '10111': 3,
        '11000': 3, '11001': 2, '11010': 3, '11011': 1, '11101': 2, '11110': 1, '11111': 471}

    counts = {'00000000': 2, '00000001': 5, '00000010': 1, '00000011': 3, '00000100': 2, '00000101': 2, '00000110': 5, '00000111': 3, '00001001': 1, '00001010': 2, '00001011': 2, '00001100': 4, '00001101': 1, '00001110': 4, '00001111': 953, '00011111': 3, '00101111': 3, '01001111': 2, '01011111': 1, '01101111': 3, '01111111': 3, '10001111': 3, '10011111': 2, '10101111': 3, '10111111': 3, '11011111': 4, '11101111': 3, '11111111': 1}
    '''
    #counts = {'00010': 87, '00011': 109, '00101': 98, '00111': 84, '01011': 89, '01101': 94, '10001': 95, '10011': 76, '10111': 98, '11101': 91, '11111': 103}

    counts = dict(sorted(counts.items()))
    obtained_freqs = {}

    if blocks>1 :
        for full_key in counts.keys() :
            obtained_freq = counts[full_key]
            keys = [full_key[j:j + block_len] for j in range(0, len(full_key), block_len)]
            for i in range(0, len(expected)) :
                expected_key = expected[i][0]
                obtained_key = keys[i]
                if expected_key == int(obtained_key, 2) :
                    obtained_freqs[obtained_key] = obtained_freqs.get(obtained_key, 0) + obtained_freq
    else :
        obtained_freqs = counts

    obtained_freqs = sorted(obtained_freqs.items())
    for obtained_key, obtained_freq in obtained_freqs :
        decimal_key = int(obtained_key, 2)
        binary_key = f"'{obtained_key}"
        freq = find(decimal_key)
        expected_freq = freq * shots * blocks
        error = abs(expected_freq - obtained_freq)

        line = [
            iteration, problem, backend_name,
            f"{ORIGINAL_QUBITS:.0f}",
            len(expected),
            decimal_key,
            binary_key,
            f"{expected_freq:.0f}",
            f"{obtained_freq:.0f}",
            f"{error:.0f}",
        ]
        details_writer.writerow(line)

    total_error = 0
    obtained_dict = dict(obtained_freqs)
    for (expected_key, freq_relative) in expected:
        expected_freq = freq_relative * shots * blocks
        bin_key = format(expected_key, f"0{ORIGINAL_QUBITS}b")
        obtained_freq = obtained_dict.get(bin_key, 0)
        total_error += abs(expected_freq - obtained_freq)

    mean_relative_error = total_error / shots / blocks
    return mean_relative_error

################################################
def print_matrixes_details(outputQubits, problem, counts, backend_name, details_writer, iteration):
    counts = dict(sorted(counts.items()))

    for key in counts.keys() :
        decimal_key = int(key, 2)
        expected_freq = int(find(decimal_key) * shots)
        actualFreq = counts[key]
        line = [
            iteration,
            problem,
            backend_name,
            f"{ORIGINAL_QUBITS:.0f}",
            len(expected),
            decimal_key,                    # 0 Decimal output
            f"'{key}",                      # 1 Binary output
            expected_freq,                   # 2 Expected absolute frequency
            actualFreq,                     # 3 Obtained absolute frequency
            abs(expected_freq - actualFreq)  # 4 Error absoluto
        ]
        details_writer.writerow(line)

    total_error = 0
    for i in range(len(expected)) :
        expected_key = format(expected[i][0], f"0{outputQubits}b")
        expected_freq = expected[i][1]*shots
        obtained_freq = counts.get(expected_key)
        if obtained_freq is None:
            obtained_freq = 0
        total_error = total_error + abs(obtained_freq - expected_freq)

    mean_relative_error = total_error / shots

    return mean_relative_error

################################################

def summarize(data, number_of_circuits):
    keys = { (row[1], row[2], row[3], row[6]) for row in data }
    result = []
    for key in keys :
        rows = [row for row in data if (row[1], row[2], row[3], row[6]) == key]
        new_row = rows[0].copy()
        new_row[10] = 0
        for row in rows[1:] :
            new_row[8] = new_row[8] + row[8]
            new_row[9] = new_row[9] + row[9]
        new_row[10] = abs(new_row[8] - new_row[9])
        del new_row[0]
        result.append(new_row)

    return result

def print_splitted_details(problem, circuit_index, counts, backend_name, iteration, searched_value):
    #counts = {'00000': 57, '00001': 30, '00010': 47, '00011': 32, '00100': 29, '00101': 26, '00110': 34, '00111': 25, '01000': 53, '01001': 33, '01010': 27, '01011': 29, '01100': 35, '01101': 37, '01110': 41, '01111': 21, '10000': 24, '10001': 35, '10010': 33, '10011': 34, '10100': 30, '10101': 27, '10110': 34, '10111': 17, '11000': 26, '11001': 39, '11010': 21, '11011': 29, '11100': 26, '11101': 35, '11110': 33, '11111': 25}

    counts = dict(sorted(counts.items()))
    lines = []
    for key in counts :
        decimal_key = int(key, 2)
        actual_occurrences = counts.get(key, 0.0)

        if decimal_key==searched_value[0] :
            current_expected_absolute_occurrences = shots
        else :
            current_expected_absolute_occurrences = 0

        error_absolute = abs(current_expected_absolute_occurrences - actual_occurrences)

        line = [
            circuit_index,
            iteration,
            problem,
            backend_name,
            qubits,
            len(expected),
            decimal_key,
            f"'{key}",
            current_expected_absolute_occurrences,
            actual_occurrences,
            error_absolute
        ]
        lines.append(line)

    return lines

def print_report(problem, qpu, qubits, t_time, e_time, r_time, g_orig, g_transp, depth_orig, depth_transp, error, writer, iteration, job_id):
    print(f"{iteration}\t{problem}\t{qpu}\t{qubits}\t{len(expected)}\t"
          f"{t_time:.4f}\t{e_time:.4f}\t{r_time:.4f}"
          f"{g_orig}\t{g_transp}\t{depth_orig}\t{depth_transp}\t{error:.6f}\t{job_id}\t{ALGORITHM}")
    writer.writerow([iteration, problem, qpu, qubits, len(expected),
                     f"{t_time:.4f}".replace('.', ','), f"{e_time:.4f}".replace('.', ','), f"{r_time:.4f}".replace('.', ','),
                     g_orig, g_transp, depth_orig, depth_transp, f"{error:.6f}".replace('.', ','), job_id, ALGORITHM])

# --------------------------------------------------------------------
# LÓGICA DE EJECUCIÓN CENTRALIZADA
# --------------------------------------------------------------------

def load_backends(choice):
    if choice == "1" :
        return [Aer.get_backend('aer_simulator')]
    elif choice == "2" :
        return fake_backends
    elif choice == "3" :
        return [Aer.get_backend('aer_simulator')] + fake_backends
    elif choice == "4" or choice == "5" :
        if choice == "4" :
            return _get_actual_backends()
        else :
            return [Aer.get_backend('aer_simulator')] + fake_backends + _get_actual_backends()

def _get_actual_backends() :
    desired_actual_qpus = ["ibm_brisbane"] #, "ibm_sherbrooke"]
    global service

    service = QiskitRuntimeService(
        channel="ibm_cloud",
        instance=IBM_INSTANCE,
        token=IBM_TOKEN
    )
    operational_backends = service.backends(simulator=False, operational=True)
    backends = []
    for ob in operational_backends :
        if ob.name in desired_actual_qpus :
            backends = backends + [ob]
    return backends

def run_problem(backends, path, module, summary_writer, details_writer, iteration: int):
    global qubits, shots, expected, ORIGINAL_QUBITS, ALGORITHM
    qubits = module.qubits
    shots = module.shots
    expected = module.expected
    ORIGINAL_QUBITS = module.ORIGINAL_QUBITS
    SPLIT = module.SPLIT
    ALGORITHM = module.ALGORITHM
    if hasattr(module, 'outputQubits') :
        outputQubits = module.outputQubits
    else :
        outputQubits = qubits

    circuits = module.circuits

    if SPLIT :
        for backend in backends:
            split_lines = []
            total_tanspilation_time = 0
            total_execution_time = 0
            total_results_time = 0
            total_original_gates = 0
            total_transpiled_gates = 0
            total_original_depth = 0
            total_transpiled_depth = 0

            job_ids = ""
            for idx, circ in enumerate(circuits):
                searched_value = expected[idx]
                try:
                    transpiled, counts, (t_t, t_e, t_result), job_id = execute_on_backend(circ, backend, path)
                    total_tanspilation_time += t_t
                    total_execution_time += t_e
                    total_results_time += t_result
                    gates_orig = sum(circ.count_ops().values())
                    gates_transp = sum(transpiled.count_ops().values())
                    depth_orig = circ.depth()
                    depth_transp = transpiled.depth()

                    total_original_gates = total_original_gates + gates_orig
                    total_transpiled_gates = total_transpiled_gates + gates_transp
                    total_original_depth = total_original_depth + depth_orig
                    total_transpiled_depth = total_transpiled_depth + depth_transp

                    if job_id is not None :
                        job_ids = job_ids + " " + job_id
                    counts = {format(int(k, 2), f'0{outputQubits}b'): v for k, v in counts.items()}
                    counts = dict(sorted(counts.items()))
                    lines = print_splitted_details(os.path.splitext(os.path.basename(module.__file__))[0],
                                idx,
                                counts,
                                backend.name if hasattr(backend, "name") else backend.backend_name,
                                iteration,
                                searched_value)
                    split_lines.extend(lines)
                except Exception as e:
                    print(f"❌ Error en {backend.name if hasattr(backend, 'name') else backend.backend_name}: {e}")
            summary_lines = summarize(split_lines, len(circuits))
            #summary_lines = split_lines + []
            summary_lines.sort(key=lambda x: x[6])
            total_error = 0
            for line in summary_lines :
                details_writer.writerow([line[0], line[1], line[2], line[3], line[4], line[5], line[6], line[7],
                                         line[8], line[9]])
                if line[7]==0 :
                    total_error += line[9]
            total_error = total_error / len(circuits)

            print_report(f"{os.path.splitext(os.path.basename(module.__file__))[0]}",
                         backend.name if hasattr(backend, "name") else backend.backend_name,
                         qubits if ORIGINAL_QUBITS==-1 else round(ORIGINAL_QUBITS),
                         total_tanspilation_time, total_execution_time, total_results_time,
                         int(total_original_gates)/len(circuits), int(total_transpiled_gates/len(circuits)),
                         int(total_original_depth/len(circuits)), int(total_transpiled_depth/len(circuits)),
                         total_error / shots,
                         summary_writer, iteration, job_ids)
    else :
        for backend in backends:
            for idx, circ in enumerate(circuits):
                try:
                    postfix = f".{idx}" if len(circuits) > 1 else ""
                    problem = f"{os.path.splitext(os.path.basename(module.__file__))[0]}{postfix}"
                    transpiled, counts, (t_t, t_e, t_result), job_id = execute_on_backend(circ, backend, path)
                    qpu = backend.name if hasattr(backend, "name") else backend.backend_name

                    print(f"{iteration}\t{problem}\t{qpu}\t{qubits}\t{len(expected)}\t"
                          f"{t_t:.4f}\t{t_e:.4f}\t")

                    if hasattr(module, "ALGORITHM") and module.ALGORITHM == "Matrixes" :
                        counts = {format(int(k, 2), f'0{outputQubits}b'): v for k, v in counts.items()}
                        mean_error = print_matrixes_details(outputQubits, os.path.splitext(os.path.basename(module.__file__))[0],
                                counts,
                                backend.name if hasattr(backend, "name") else backend.backend_name,
                                details_writer,
                                iteration)
                    else:
                        counts = {format(int(k, 2), f'0{outputQubits}b'): v for k, v in counts.items()}
                        mean_error = print_parallel_details(iteration, os.path.splitext(os.path.basename(module.__file__))[0],
                                counts,
                                backend.name if hasattr(backend, "name") else backend.backend_name,
                                details_writer)

                    gates_orig = sum(circ.count_ops().values())
                    gates_transp = sum(transpiled.count_ops().values())
                    depth_orig = circ.depth()
                    depth_transp = transpiled.depth()
                    print_report(f"{os.path.splitext(os.path.basename(module.__file__))[0]}{postfix}",
                                 backend.name if hasattr(backend, "name") else backend.backend_name,
                                 qubits if ORIGINAL_QUBITS==-1 else round(ORIGINAL_QUBITS),
                                 t_t, t_e, t_result,
                                 gates_orig, gates_transp,
                                 depth_orig, depth_transp,
                                 mean_error,
                                 summary_writer, iteration, job_id)
                except Exception as e:
                    print(f"❌ Error en {backend.name if hasattr(backend, 'name') else backend.backend_name}: {e}")

# --------------------------------------------------------------------
# ENTRADA PRINCIPAL
# --------------------------------------------------------------------

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("❌ Uso: python run.py <patrón módulos> <iteraciones> <append results to existing .csv files: y/n>")
        sys.exit(1)

    pattern = sys.argv[1]
    iterations = int(sys.argv[2])
    append_flag = sys.argv[3].lower()

    if append_flag not in {"y", "n"}:
        print("❌ El tercer parámetro debe ser 'y' (añadir a los CSV existentes) o 'n' (sobrescribir los CSV).")
        sys.exit(1)

    append_mode = append_flag == "y"

    # Localizar archivos según patrón
    py_paths = sorted(glob.glob(pattern))
    if not py_paths:
        print(f"⚠️ No se hallaron módulos: {pattern}")
        sys.exit(1)

    # Determinar directorio de salida: común a todos los archivos
    dirs = {os.path.dirname(p) or '.' for p in py_paths}
    out_dir = dirs.pop() if len(dirs) == 1 else '.'

    # Limpiar CSVs previos si no estamos en modo append
    if not append_mode:
        for f in glob.glob(os.path.join(out_dir, '*.csv')):
            os.remove(f)

    choice = menu()
    print("Leyendo backends. Si has elegido actual_backends, puede tardar unos segundos")
    backends = load_backends(choice)

    # Precarga de los backends
    print("\nPRECARGANDO BACKENDS...")
    fake_circuit = QuantumCircuit(1, 1)
    fake_circuit.x(0)
    fake_circuit.measure(0, 0)
    contador = 1
    shots = 1
    for backend in backends:
        print(f"\t{backend.name} ({contador} de {len(backends)})")
        if hasattr(backend, "status"):
            if not hasattr(backend, "backend_name"):
                print(f"\t\toperational: {getattr(backend.status(), 'operational')}")
                print(f"\t\t\texecuting precharge... ", end="")
                execute_on_backend(fake_circuit, backend)
                print("✅")
            elif backend.backend_name.startswith("fake"):
                print(f"\t\toperational: {getattr(backend.status(), 'operational')}")
                print(f"\t\t\texecuting precharge... ", end="")
                execute_on_backend(fake_circuit, backend)
                print("✅")
            else:
                print(f"\t\tactual backend: {backend.backend_name} (actual), no precharge ✅")
        contador += 1

    print("\nCARGANDO MÓDULO")

    summary_hdr = [
        'Iteration','Problem','QPU','Qubits','Searched',
        'T_transp','T_exec','T_res','G_orig','G_transp','depth_orig', 'depth_transp', 'Mean_err', "Job id", "Algorithm"
    ]
    details_hdr = [
        "Iter","Problem","QPU","Qubits","Searched",
        "Dec","Bin","Expected","Obtained","Error"
    ]

    summary_path = os.path.join(out_dir, 'summary.csv')
    details_path = os.path.join(out_dir, 'all_results.csv')

    with open(summary_path, 'a' if append_mode else 'w', newline='', buffering=1) as sf, \
         open(details_path, 'a' if append_mode else 'w', newline='', buffering=1) as df:

        sw = csv.writer(sf, delimiter='\t')
        dw = csv.writer(df, delimiter='\t')

        if not append_mode:
            sw.writerow(summary_hdr)
            dw.writerow(details_hdr)

        print(*summary_hdr, sep="\t")

        for i in range(1, iterations + 1):
            for path in py_paths:
                try:
                    module = load_module_from_path(path)
                except Exception as e:
                    print(f"❌ No se pudo importar {path}: {e}")
                    continue
                if hasattr(module, "qubits"):
                    run_problem(backends, path, module, sw, dw, i)
